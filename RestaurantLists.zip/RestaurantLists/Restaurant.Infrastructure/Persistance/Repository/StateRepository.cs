﻿using Restaurant.Domain.Repositories;
using Restaurant.Infrastructure.Persistance.Data;
using Restaurant.Infrastructure.Persistance.Repository.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Restaurant.Infrastructure.Persistance.Repository
{
    public class StateRepository : Repository<Restaurant.Domain.Entities.RestaurantState>, IStateRepository
    {
        private readonly RestaurantDetailsDbContext restaurantDetailsDbContext;

        public StateRepository(RestaurantDetailsDbContext restaurantDetailsDbContext) : base(restaurantDetailsDbContext)
        {
            this.restaurantDetailsDbContext = restaurantDetailsDbContext;
        }
    }
}
