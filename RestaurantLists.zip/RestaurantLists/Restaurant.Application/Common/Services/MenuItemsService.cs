﻿using Restaurant.Application.Common.Interfaces;
using Restaurant.Domain.Entities;
using Restaurant.Domain.Repositories;
using Restaurant.Infrastructure.Persistance.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Restaurant.Application.Common.Services
{
    public class MenuItemsService:IMenuItemsService
    {
        private readonly IMenuItemsRepository _menuItemsRepository;

        public MenuItemsService(IMenuItemsRepository _menuItemsRepository)
        {
            this._menuItemsRepository = _menuItemsRepository;
        }

        public async Task<RestaurantMenuItems> AddAsync(RestaurantMenuItems menuItems)
        {
            return await _menuItemsRepository.AddAsync(menuItems);
        }

        public async Task<RestaurantMenuItems> DeleteAsync(int id)
        {
            return await _menuItemsRepository.DeleteAsync(id);
        }

        public async Task<IEnumerable<RestaurantMenuItems>> GetAllAsync()
        {
            return await _menuItemsRepository.GetAllAsync();
        }

        public async Task<RestaurantMenuItems> GetAsync(int id)
        {
            return await _menuItemsRepository.GetAsync(id);
        }

        public async Task<RestaurantMenuItems> UpdateAsync(int id, RestaurantMenuItems updated)
        {
            return await _menuItemsRepository.UpdateAsync(id, updated);
        }
    }
}
