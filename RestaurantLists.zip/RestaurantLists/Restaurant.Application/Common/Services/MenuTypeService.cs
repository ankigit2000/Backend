﻿using Restaurant.Application.Common.Interfaces;
using Restaurant.Domain.Entities;
using Restaurant.Domain.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Restaurant.Application.Common.Services
{
    public class MenuTypeService:IMenuTypeService
    {
        private readonly IMenuTypeRepository _menuTypeRepository;

        public MenuTypeService(IMenuTypeRepository _menuTypeRepository)
        {
            this._menuTypeRepository = _menuTypeRepository;
        }

        public async Task<RestaurantMenuType> AddAsync(RestaurantMenuType menuType)
        {
            return await _menuTypeRepository.AddAsync(menuType);
        }

        public async Task<RestaurantMenuType> DeleteAsync(int id)
        {
            return await _menuTypeRepository.DeleteAsync(id);
        }

        public async Task<IEnumerable<RestaurantMenuType>> GetAllAsync()
        {
            return await _menuTypeRepository.GetAllAsync();
        }

        public async Task<RestaurantMenuType> GetAsync(int id)
        {
            return await _menuTypeRepository.GetAsync(id);
        }

        public async Task<RestaurantMenuType> UpdateAsync(int id, RestaurantMenuType updated)
        {
            return await _menuTypeRepository.UpdateAsync(id, updated);
        }
    }
}
