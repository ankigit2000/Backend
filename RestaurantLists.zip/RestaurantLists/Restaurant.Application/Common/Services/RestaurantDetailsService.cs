﻿using Restaurant.Application.Common.Interfaces;
using Restaurant.Domain.Entities;
using Restaurant.Domain.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Restaurant.Application.Common.Services
{
    public class RestaurantDetailsService:IRestaurantDetailsService
    {
        private readonly IRestaurantDetailsRepository _restaurantDetailsRepository;

        public RestaurantDetailsService(IRestaurantDetailsRepository _restaurantDetailsRepository)
        {
            this._restaurantDetailsRepository = _restaurantDetailsRepository;
        }

        public Task<RestaurantDetails> AddAsync(RestaurantDetails restaurantDetails)
        {
            return _restaurantDetailsRepository.AddAsync(restaurantDetails);
        }

        public Task<RestaurantDetails> DeleteAsync(int id)
        {
            return _restaurantDetailsRepository.DeleteAsync(id);
        }

        public Task<IEnumerable<RestaurantDetails>> GetAllAsync()
        {
            return _restaurantDetailsRepository.GetAllAsync();
        }

        public Task<RestaurantDetails> GetAsync(int id)
        {
            return _restaurantDetailsRepository.GetAsync(id);
        }

        public Task<RestaurantDetails> UpdateAsync(int id, RestaurantDetails updated)
        {
            return _restaurantDetailsRepository.UpdateAsync(id, updated);
        }
    }
}
