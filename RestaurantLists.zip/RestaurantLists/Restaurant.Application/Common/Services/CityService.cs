﻿using Restaurant.Application.Common.Interfaces;
using Restaurant.Domain.Entities;
using Restaurant.Domain.Repositories;

namespace Restaurant.Application.Common.Services
{
    public class CityService : ICityService
    {
        private readonly ICityRepository _cityRepository;

        public CityService(ICityRepository _cityRepository) 
        {
            this._cityRepository = _cityRepository;
        }

        public async Task<RestaurantCity> AddAsync(RestaurantCity city)
        {
           return await _cityRepository.AddAsync(city);
        }

        public async Task<RestaurantCity> DeleteAsync(int id)
        {
            return await _cityRepository.DeleteAsync(id);
        }

        public async Task<IEnumerable<RestaurantCity>> GetAllAsync()
        {
           return await _cityRepository.GetAllAsync();    
        }

        public async Task<RestaurantCity> GetAsync(int id)
        {
            return await _cityRepository.GetAsync(id);
        }

        public async Task<RestaurantCity> UpdateAsync(int id, RestaurantCity updated)
        {
            return await _cityRepository.UpdateAsync(id, updated);    
        }
    }
}
