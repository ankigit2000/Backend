﻿using Restaurant.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Restaurant.Application.Common.Interfaces
{
    public interface ICityService
    {
        Task<IEnumerable<RestaurantCity>> GetAllAsync();
        Task<RestaurantCity> GetAsync(int id);

        Task<RestaurantCity> AddAsync(RestaurantCity city);

        Task<RestaurantCity> DeleteAsync(int id);

        Task<RestaurantCity> UpdateAsync(int id, RestaurantCity updated);
    }
}
